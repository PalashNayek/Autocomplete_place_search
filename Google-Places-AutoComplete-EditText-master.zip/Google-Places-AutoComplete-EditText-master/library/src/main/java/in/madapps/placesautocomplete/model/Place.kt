package `in`.madapps.placesautocomplete.model

/**
 * Created by mukeshsolanki on 28/02/19.
 */
data class Place(
  val id: String,
  val description: String
) {
  override fun toString(): String {
    return ""
  }
}