package `in`.madapps.placesautocomplete.exception

/**
 * Created by mukeshsolanki on 05/03/19.
 */
class InitializationException(message: String?) : Exception(message)
