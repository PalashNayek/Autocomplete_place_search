package `in`.madapps.placesautocomplete.model

/**
 * Created by mukeshsolanki on 28/02/19.
 */
data class Address(val longName: String, val shortName: String, val type: ArrayList<String>)