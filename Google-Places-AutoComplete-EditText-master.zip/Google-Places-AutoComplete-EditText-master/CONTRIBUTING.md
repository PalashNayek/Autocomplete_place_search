[![GitHub contributors](https://img.shields.io/github/contributors/mukeshsolanki/Google-Places-AutoComplete-EditText.svg)](https://github.com/mukeshsolanki/Google-Places-AutoComplete-EditText/graphs/contributors)

* Bug reports and pull requests are welcome.
* Make sure you use [square/java-code-styles](https://github.com/square/java-code-styles) to format your code.
