# Backers

Google Places AutoComplete EditText is an independent project with ongoing development and support made possible thanks to donations made by these awesome backers. If you'd like to join them, please consider:

- [Become a backer or sponsor on Patreon](https://www.patreon.com/mukeshsolanki).
- [One-time donation via PayPal](https://www.paypal.me/mukeshsolanki)

<a href="https://www.patreon.com/bePatron?c=935498" alt="Become a Patron"><img src="https://c5.patreon.com/external/logo/become_a_patron_button.png" /></a>

Thank you to everyone who has donated their time, money, and support!

## Backers ($1 per month)
- Be the first to back this project